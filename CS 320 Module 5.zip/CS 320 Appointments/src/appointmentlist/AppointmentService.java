package appointmentlist;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

	    private Map<String, Appointment> appointments;
	    
	    public AppointmentService() {
	        this.appointments = new HashMap<>();
	    }

	 // Adds a new appointment
	    public void addAppointment(Appointment appointment) {
	        String appointmentID = appointment.getAppointmentId();
	        appointments.put(appointmentID, appointment);
	    }

	    // Retrieves an appointment by ID
	    public Appointment getAppointment(String appointmentID) {
	        return appointments.get(appointmentID);
	    }

	    // Deletes an appointment by ID
	    public void deleteAppointment(String appointmentID) {
	        appointments.remove(appointmentID);
	    }

	    // Checks if an appointment exists
	    public boolean hasAppointment(String appointmentID) {
	        return appointments.containsKey(appointmentID);
	    }
	}
