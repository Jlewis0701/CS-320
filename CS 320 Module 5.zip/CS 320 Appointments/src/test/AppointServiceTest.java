package test;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import appointmentlist.Appointment;
import appointmentlist.AppointmentService;

class AppointServiceTest {
	
	private AppointmentService service;
    private Appointment appointment1;
    private Date futureDate;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        futureDate = new Date(System.currentTimeMillis() +  24 * 60 * 60 * 1000); // A future date
        appointment1 = new Appointment("D2342", futureDate, "Dentist Appointment");
    }

    @Test
    public void testAddAppointment() {
        // Initially, the service should not have the appointment
        assertFalse(service.hasAppointment(appointment1.getAppointmentId()), "Service should start without this appointment");

        // Adding the appointment
        service.addAppointment(appointment1);
        assertTrue(service.hasAppointment(appointment1.getAppointmentId()), "Appointment should be added");

        // Confirm the added appointment is the same as the one we put in
        assertEquals(appointment1, service.getAppointment(appointment1.getAppointmentId()), "The added appointment should match the retrieved one");
    }

    @Test
    public void testDeleteAppointment() {
        service.addAppointment(appointment1);
        assertTrue(service.hasAppointment(appointment1.getAppointmentId()), "Appointment should be added successfully");
        
        // delete the appointment
        service.deleteAppointment(appointment1.getAppointmentId());
        assertFalse(service.hasAppointment(appointment1.getAppointmentId()), "Appointment should be removed after deletion");
    }
    
}
