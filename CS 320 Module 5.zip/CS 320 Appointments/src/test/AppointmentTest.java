package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import appointmentlist.Appointment;

import java.util.Date;

class AppointmentTest {
	
	@Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // 100 seconds into the future
        Appointment appointment = new Appointment("ID12345", futureDate, "Regular check-up");
        assertNotNull(appointment);
        assertEquals("ID12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Regular check-up", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Check-up"),
            "Appointment ID must not be null and cannot be longer than 10 characters");
    }

    @Test
    public void testAppointmentIdTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Check-up"),
            "Appointment ID must not be null and cannot be longer than 10 characters");
    }

    @Test
    public void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID12345", null, "Check-up"),
            "Appointment date must not be null and cannot be in the past");
    }

    @Test
    public void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // 100 seconds in the past
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID12345", pastDate, "Check-up"),
            "Appointment date must not be null and cannot be in the past");
    }

    @Test
    public void testDescriptionNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID12345", futureDate, null),
            "Description must not be null and cannot be longer than 50 characters");
    }

    @Test
    public void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDescription = "This description is definitely way too long and should cause the constructor to throw an exception because it is well over fifty characters";
        assertThrows(IllegalArgumentException.class, () -> new Appointment("ID12345", futureDate, longDescription),
            "Description must not be null and cannot be longer than 50 characters");
    }
}