package contactlist;
import java.util.HashMap;
import java.util.Map;
import contactlist.Contact;

public class ContactService {
	private Map<String, Contact> contacts;

        public ContactService() {
            this.contacts = new HashMap<>();
        }
            
    public void addContact(String contactId, String firstName, String lastName, String phone, String address) {
    	Contact contact = new Contact(contactId, firstName, lastName, phone, address);
       // Assuming contactId is unique and used as the key for quick searches.
    	contacts.put(contactId, contact);
        }
        
    public Contact getContact(String contactId) {
    	return contacts.get(contactId);
        }

    public void deleteContact(String contactId) {
        contacts.remove(contactId);
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact contact = getContact(contactId);
        if (contact != null) {
            contact.setFirstName(firstName);
        }
    }

    public void updateLastName(String contactId, String lastName) {
        Contact contact = getContact(contactId);
        if (contact != null) {
            contact.setLastName(lastName);
        }
    }

    public void updatePhone(String contactId, String phone) {
        Contact contact = getContact(contactId);
        if (contact != null) {
            contact.setPhone(phone);
        }
    }

    public void updateAddress(String contactId, String address) {
        Contact contact = getContact(contactId);
        if (contact != null) {
            contact.setAddress(address);
        }
    }
    
    public boolean hasContact(String contactId) {
        return contacts.containsKey(contactId);
    }
}

