package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import contactlist.Contact;

class ContactTest {
	
	
	@Test
	void testContactCreate() {
		
	Contact contact = new Contact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
	assertEquals("1234567890", contact.getContactId());
	assertEquals("Mike", contact.getFirstName()) ;
	assertEquals("Smith", contact.getLastName());
	assertEquals("2345678913", contact.getPhone());
	assertEquals("811 Mulberry Avenue", contact.getAddress());
	}
	
	@Test
	void testContactIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Mike", "Smith", "2345678913", "811 Mulberry Avenue"));
		assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890123", "Mike", "Smith", "2345678913", "811 Mulberry Avenue"));
	}
	
	@Test
	void testContactFirstNameTooLong() {
		Contact contact = new Contact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("MikeJohnson"));
	}
	
	@Test
	void testContactLastNameTooLong() {
		Contact contact = new Contact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setLastName("SmithStevens"));
	}
	
	@Test
	void testContactPhoneExact() {
		Contact contact = new Contact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone("234567894553"));
		assertThrows(IllegalArgumentException.class, () -> contact.setPhone("23456"));
	}
	
	@Test
	void testContactAddressTooLong() {
		Contact contact = new Contact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
		assertThrows(IllegalArgumentException.class, () -> contact.setAddress("811 Mulberry Avenue Address Over Thirty Characters"));
	}
}
	
