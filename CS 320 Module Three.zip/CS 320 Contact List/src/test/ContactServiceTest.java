package test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import contactlist.ContactService;

class ContactServiceTest {
	
    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

	@Test
    void testAddContact() {
		   service.addContact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
		   assertTrue(service.hasContact("1234567890"));
	    }
	
	@Test
    void testDeleteContact() {
		service.addContact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
        service.deleteContact("1234567890");
        assertFalse(service.hasContact("1234567890"));
    }
	
	@Test
    void testUpdateFirstName() {
		service.addContact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
        service.updateFirstName("1234567890", "Mikayla");
        assertEquals("Mikayla", service.getContact("1234567890").getFirstName());
    }

	@Test
    void testUpdateLastName() {
		service.addContact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
        service.updateLastName("1234567890", "Stevens");
        assertEquals("Stevens", service.getContact("1234567890").getLastName());
    }
	
	@Test
    void testUpdatePhone() {
		service.addContact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
        service.updatePhone("1234567890", "4564523910");
        assertEquals("4564523910", service.getContact("1234567890").getPhone());
    }
	
	@Test
    void testUpdateAddress() {
		service.addContact("1234567890", "Mike", "Smith", "2345678913", "811 Mulberry Avenue");
        service.updateAddress("1234567890", "204 North Avenue");
        assertEquals("204 North Avenue", service.getContact("1234567890").getAddress());
    }
}
